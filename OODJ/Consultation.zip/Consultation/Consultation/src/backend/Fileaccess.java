package backend;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Fileaccess extends filereader{
    //Polymorphism:: Method overriding
    @Override
    public ArrayList<String> readAll() {
        ArrayList<String> list = new ArrayList();
        //Scanner/BufferedReader
        try (Scanner scan = new Scanner(this.filename)) {
            //reading
            while (scan.hasNextLine()) {
                String line = scan.nextLine();
                //populate it into list object
                list.add(line);
            }
            scan.close();
        } catch (IOException ex) {
            //any exception/error happen
            ex.printStackTrace();
        }
        return list;
    }
    
    @Override
    public boolean write(String record) {
        //PrintWriter
        try (PrintWriter out = new PrintWriter(new FileWriter(this.filename, true))) {
            out.println(record);//write to file
            //if 'write' is succeeded
            out.close();
            return true;
        } catch (IOException ex) {
            //any exception/error
            System.out.println("Error: Failed to write.");
            return false;
        }
    }

    public boolean write(ArrayList<String> data) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
