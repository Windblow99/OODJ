package backend;

import java.util.ArrayList;

public class textbinary extends Fileaccess{
    @Override
    public ArrayList<String> readAll() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
    @Override
    public boolean write(String record) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
    
}
