
package modules;

import backend.Fileaccess;
import javax.swing.JOptionPane;

public abstract class ConsultationSystem {
    
    protected Fileaccess fa;
    protected String venue,date,timestart,timeend;
    protected String id;
    
    protected String newvenue, newdate, newtimestart, newtimeend;

    public String getNewvenue() {
        return newvenue;
    }

    public void setNewvenue(String newvenue) {
        this.newvenue = newvenue;
    }

    public String getNewdate() {
        return newdate;
    }

    public void setNewdate(String newdate) {
        this.newdate = newdate;
    }

    public String getNewtimestart() {
        return newtimestart;
    }

    public void setNewtimestart(String newtimestart) {
        this.newtimestart = newtimestart;
    }

    public String getNewtimeend() {
        return newtimeend;
    }

    public void setNewtimeend(String newtimeend) {
        this.newtimeend = newtimeend;
    }

    
    public void setVenue(String venue){
        this.venue = venue;
    }
    
    public void setDate(String date){
        this.date = date;
    }
    
    public void setTimeStart(String timestart){
        this.timestart = timestart;
    }
    
    public void setTimeEnd(String timeend){
        this.timeend = timeend;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    
    public boolean booking(){
        JOptionPane.showMessageDialog(null, "Fail to book");
        return false;
    }
    
    public boolean EditConsultationHour(){
        JOptionPane.showMessageDialog(null, "Update Fail");
        return false;
    }
    
    public boolean EditVenue() {
        JOptionPane.showMessageDialog(null, "Fail to Edit");
        return false;
    }
    
    
}
