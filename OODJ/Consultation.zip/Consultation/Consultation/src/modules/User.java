package modules;

import backend.Fileaccess;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

public class User {
    
    private Fileaccess fa;
    private String username,password;
    private int role;
    
    private String newname, newcontact, newemail, newdegreelevel;

    public User(String username, String password, int role, String newname, String newcontact, String newemail, String newdegreelevel) {
        this.username = username;
        this.password = password;
        this.role = role;
        this.newname = newname;
        this.newcontact = newcontact;
        this.newemail = newemail;
        this.newdegreelevel = newdegreelevel;
    }
    
    public User(){
        fa = new Fileaccess();
        fa.setFileName("user.txt");
    }
    
    public String getNewname() {
        return newname;
    }

    public void setNewname(String newname) {
        this.newname = newname;
    }

    public String getNewcontact() {
        return newcontact;
    }

    public void setNewcontact(String newcontact) {
        this.newcontact = newcontact;
    }

    public String getNewemail() {
        return newemail;
    }

    public void setNewemail(String newemail) {
        this.newemail = newemail;
    }

    public String getNewdegreelevel() {
        return newdegreelevel;
    }

    public void setNewdegreelevel(String newdegreelevel) {
        this.newdegreelevel = newdegreelevel;
    }
    
    
    public static String currentUser;
    
    public void setUsername(String usn){
        this.username = usn;
    }

    public void setPassword(String pwd){
        this.password = pwd;
    }

    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }


    public boolean login (){
       boolean status = false;
       ArrayList<String> data = fa.readAll();
        for (String record : data) {
            String[] split = record.split("//");
            if (split[0].equals(username) && split[1].equals(password)) {
                role = Integer.parseInt(split[2]);
                status = true;
                currentUser = username;
                break;
            }
        }
        return status;
    }             

   public boolean EditProfile() {
        File filename = new File("user.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            if (split[0].equals(User.currentUser)) {
                String newRecordLine = String.join("//", User.currentUser, split[1], split[2], newname, newcontact, newemail, newdegreelevel);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
        
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
             }
                
    }
}
