package modules;

import backend.Fileaccess;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;


public class ConsultationVenue extends ConsultationSystem {

    public ConsultationVenue(){
        fa = new Fileaccess();
        fa.setFileName("venue.txt");
    }
    

    public String create(){
        
        Long aid = Func.generateUniqueId();
        id = Long.toString(aid);
        
        String status = "false";
        String record = String.join("//", venue, id);
        boolean ok = fa.write(record);
        if(ok){
            return record;
        }else{
            return status;
        }
        
    }
    
    public boolean validate (){
       boolean status = false;
       ArrayList<String> data = fa.readAll();
        for (String record : data) {
            String[] split = record.split("//");
            if (split[0].equals(venue)) {
                status = true;
                break;
            }
        }
        return status;
    } 
    
    @Override
    public boolean EditVenue() {
        File filename = new File("venue.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            
            if (split[1].equals(id)) {
                String newRecordLine = String.join("//", newvenue, split[1]);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
        
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }
                
    }
    
    public boolean Delete() {
        
        boolean success = false;
        
        File filename = new File("venue.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            if (!split[1].equals(id)) {
                new_list.add(oldLine);
            }  
        }

            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                    success = true;
                }
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (old_list.size() == 1){
                success = true;
            
        }
            return success; 
     }
}
