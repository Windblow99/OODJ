package modules;

import backend.Fileaccess;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import static modules.User.currentUser;

public class ConsultationHour extends ConsultationSystem{

    
    public ConsultationHour(){
        fa = new Fileaccess();
        fa.setFileName("booking.txt");
    }
    
    
    public boolean validate (){
       boolean status = false;
       ArrayList<String> data = fa.readAll();
        for (String record : data) {
            String[] split = record.split("//");
            if (split[0].equals(venue) && split[1].equals(date) && split[2].equals(timestart) && split[3].equals(timeend) && split[4].equals("Available") && split[6].equals(User.currentUser)) {
                status = true;
                break;
            }else if (split[0].equals(venue) && split[1].equals(date) && (split[2].equals(timestart) || split[3].equals(timeend)) && split[4].equals("Available") && split[6].equals(User.currentUser)) {
                status = true;
                break;
            }
        }
        return status;
    }

    
    public String create(){
        
        Long aid = Func.generateUniqueId();
        id = Long.toString(aid);
        
        String status = "false";
        String record = String.join("//", venue, date, timestart, timeend, "Available", "None", User.currentUser, id);
        boolean ok = fa.write(record);
        if(ok){
            return record;
        }else{
            return status;
        }
        
    }
    
    @Override
    public boolean booking() {
        File filename = new File("booking.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            if (split[7].equals(id)) {
                
                String newRecordLine = String.join("//", split[0], split[1], split[2], split[3], "Booked", User.currentUser, split[6], split[7]);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }
                
    }
    
    
    @Override
    public boolean EditConsultationHour() {
        File filename = new File("booking.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            if (split[7].equals(id)) {
                String newRecordLine = String.join("//", newvenue, newdate, newtimestart, newtimeend, split[4], split[5], split[6], split[7]);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
        
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }
                
    }
    
    
    public boolean cancelbooking() {
        File filename = new File("booking.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {
            
            String[] split = oldLine.split("//");
            if (split[7].equals(id)) {
                String newRecordLine = String.join("//", split[0], split[1], split[2], split[3], "Available", "None", split[6], split[7]);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }         
    }
    
    
        public boolean cancelconsultationhour() {
        File filename = new File("booking.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            if (split[7].equals(id)) {
               
                String newRecordLine = String.join("//", split[0], split[1], split[2], split[3], "Canceled", split[5], split[6], split[7]);
                new_list.add(newRecordLine);
            } else {
                new_list.add(oldLine);
            }
        }
        
                if(new_list.size() > 0){
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }else{
            return false;
        }
                
    }
    
    
    
    
    public boolean Delete() {
        
        boolean success = false;
        
        File filename = new File("booking.txt");
        ArrayList<String> old_list = fa.readAll();
        ArrayList<String> new_list = new ArrayList();
        
        for (String oldLine : old_list) {

            String[] split = oldLine.split("//");
            
            if (!split[7].equals(id)) {
                new_list.add(oldLine);
                }
            }
        
            try(PrintWriter out = new PrintWriter(new FileWriter(filename))) {
                for (String line : new_list) {
                    out.println(line);
                    success = true;
                    }
                out.close();
            } catch (Exception e) {
                e.printStackTrace();
                }
            if (old_list.size() == 1){
                success = true;
            }
            return success;
        }
}

    
    

    
   
