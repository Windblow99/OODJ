package modules;

import backend.Fileaccess;
import java.util.ArrayList;

public class ProfileReader {
    private Fileaccess fa;
    private String name, level, contact, email;
    private int role;
    
    public int getRole() {
        return role;
    }

    public void setRole(int role) {
        this.role = role;
    }
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    //constructor
    public ProfileReader(){
        fa = new Fileaccess();
        fa.setFileName("user.txt");
    }
    
    public boolean data (){
       boolean status = false;
       ArrayList<String> data = fa.readAll();
        for (String record : data) {
            String[] split = record.split("//");
            if (split[0].equals(User.currentUser)) {
                role = Integer.parseInt(split[2]);
                name = split[3];
                contact = split[4];
                email = split[5];
                level = split[6];
                status = true;
                break;
            }
        }
        return status;
    } 
}
