package modules;

import backend.Fileaccess;
import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class JavaTeam {
    
        private Fileaccess fa;
        private String text;
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
                
     public JavaTeam(){
         fa = new Fileaccess();
         fa.setFileName("feedback.txt");
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
    
    public String create(){
        
        
        String status = "false";
        String record = String.join(": ", dtf.format(now), User.currentUser, text );
        
        boolean ok = fa.write(record);
        if(ok){
            return record;
        }else{
            return status;
        }
        
    }
}
